package com.example.user.battleshipapp;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import pl.droidsonroids.gif.GifImageView;


public class MainActivity extends AppCompatActivity {

    Button buttonStartGame7x7 ,buttonStartGame8x8, buttonStartGame9x9 ;
    Button buttonCredits;
    Button buttonHighScore;
    Button buttonGuide;
    Animation animAlpha;
    Animation animAlpha2;
    GifImageView explosionIv;
    ImageView titleIv;
    public static MediaPlayer explosionSound;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonStartGame7x7 = findViewById(R.id.button_start_game7x7);
        buttonStartGame8x8 = findViewById(R.id.button_start_game8x8);
        buttonStartGame9x9 = findViewById(R.id.button_start_game9x9);
        buttonHighScore = findViewById(R.id.button_high_score);
        buttonGuide = findViewById(R.id.button_guide);
        buttonCredits = findViewById(R.id.button_credits);

        explosionSound = MediaPlayer.create(this , R.raw.explosion_sound);
        explosionSound.start();

        explosionIv = findViewById(R.id.explosion);
        titleIv = findViewById(R.id.title_IV);
        animAlpha = AnimationUtils.loadAnimation(this , R.anim.anim_alpha);
        animAlpha2 = AnimationUtils.loadAnimation(this , R.anim.anim_alpha2);

        titleIv.setVisibility(View.INVISIBLE);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                titleIv.setVisibility(View.VISIBLE);
                titleIv.startAnimation(animAlpha2);
                explosionIv.setVisibility(View.INVISIBLE);
            }
        },1000);


        buttonCredits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentCredits = new Intent(MainActivity.this, Credits.class);
                startActivity(intentCredits);
            }
        });
        buttonHighScore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentBestScore = new Intent(MainActivity.this, BestScore.class);
                startActivity(intentBestScore);
            }
        });

        buttonStartGame7x7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentStartGame7x7 = new Intent(MainActivity.this, GamePage.class);
                intentStartGame7x7.putExtra("numOfCells", 7);
                startActivity(intentStartGame7x7);
            }
        });
        buttonStartGame8x8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentStartGame8x8 = new Intent(MainActivity.this, GamePage.class);
                intentStartGame8x8.putExtra("numOfCells", 8);
                startActivity(intentStartGame8x8);
            }
        });
        buttonStartGame9x9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentStartGame9x9 = new Intent(MainActivity.this, GamePage.class);
                intentStartGame9x9.putExtra("numOfCells", 9);
                startActivity(intentStartGame9x9);
            }
        });
        buttonGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent intentGuide = new Intent(MainActivity.this, GameGuide.class);
                startActivity(intentGuide);
            }
        });
    }
}
