package com.example.user.battleshipapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class BestScore extends AppCompatActivity {

    Long lastScore;
    Long best1 , best2 , best3;
    SharedPreferences preferences;
    Button backToMainMenu, shareScore;
    String SMS_Body;

    TextView lastScore_tv, best1_tv , best2_tv , best3_tv ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_best_score);

        lastScore_tv = findViewById(R.id.tv_score_last_score);
        best1_tv = findViewById(R.id.tv_score_best1);
        best2_tv = findViewById(R.id.tv_score_best2);
        best3_tv = findViewById(R.id.tv_score_best3);
        backToMainMenu = findViewById(R.id.button_backMainMenu2);
        shareScore = findViewById(R.id.button_share_last_score);

        preferences = getSharedPreferences("PREFS" , 0);
        lastScore = preferences.getLong("lastScore", 0);
        best1 = preferences.getLong("best1", 0);
        best2 = preferences.getLong("best2", 0);
        best3 = preferences.getLong("best3", 0);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this , new String[]{Manifest.permission.SEND_SMS}, 1);
            }
        }

        shareScore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SMS_Body = "WOW I Won in battleShip and my score is: " + lastScore + " let see if you can make better score";
                Uri uri = Uri.parse("smsto:");
                Intent it = new Intent(Intent.ACTION_SENDTO, uri);
                it.putExtra("sms_body", SMS_Body);
                startActivity(it);
            }
        });

        backToMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(BestScore.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });

        lastScore_tv.setText("Last Score: " + lastScore);
        best1_tv.setText("Best 1: " + best1);
        best2_tv.setText("Best 2: " + best2);
        best3_tv.setText("Best 3: " + best3);
    }


}
