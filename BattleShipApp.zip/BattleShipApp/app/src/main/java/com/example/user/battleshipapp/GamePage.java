package com.example.user.battleshipapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

import pl.droidsonroids.gif.GifImageView;


public class GamePage extends AppCompatActivity {
    private int numCellsBoardSide;
    private TextView textViewGameStage, textViewMessage, textViewTime;
    private Button buttonAttack, buttonUpgrade, buttonRestart , buttonBack;
    private GridView gridViewBoard1, gridViewBoard2;
    private GameBoard adapterBoard1, adapterBoard2;
    public int cellNumber;
    GridView m_gridView1 , m_gridView2;
    SharedPreferences preferences;
    GameLogic game = new GameLogic();
    BestScore initialScore = new BestScore();
    SharedPreferences.Editor editor;
    Long best1 , best2 , best3 , lastScore;
    Animation animScale , animAlpha;
    public static GifImageView explosionWinGif;
    MediaPlayer bgmusic;
    boolean isMusicOn= true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_board);

        setFields();
        enableGame();

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                Intent i=new Intent(GamePage.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });
    }

    private void enableGame() {

        game.setFields(this, numCellsBoardSide, textViewGameStage, textViewMessage,textViewTime,
                buttonAttack, buttonUpgrade, buttonRestart,
                gridViewBoard1, gridViewBoard2, adapterBoard1, adapterBoard2,preferences , initialScore , editor,
                best1, best2, best3, lastScore , animScale , animAlpha);
        game.initialize();
        game.updateTimer();
    }

    private void setFields() {
        Intent m_intent = getIntent();
        cellNumber = m_intent.getIntExtra("numOfCells", 7);
        m_gridView1 = findViewById(R.id.gridViewBoard1);
        m_gridView2 = findViewById(R.id.gridViewBoard2);
        m_gridView1.setNumColumns(cellNumber);
        m_gridView2.setNumColumns(cellNumber);
        numCellsBoardSide = cellNumber;
        textViewGameStage =  findViewById(R.id.text_view_game_stage);
        textViewMessage =  findViewById(R.id.text_view_message);
        textViewTime = findViewById(R.id.text_view_time);
        buttonRestart =  findViewById(R.id.button_initialize);
        buttonAttack =  findViewById(R.id.button_attack);
        buttonUpgrade =  findViewById(R.id.button_upgrade);
        buttonBack = findViewById(R.id.button_back);
        gridViewBoard1 =  findViewById(R.id.gridViewBoard1);
        gridViewBoard2 =  findViewById(R.id.gridViewBoard2);
        adapterBoard1 = new GameBoard(this, new ArrayList<Cell>());
        adapterBoard2 = new GameBoard(this, new ArrayList<Cell>());
        preferences = getSharedPreferences("PREFS" , 0);
        editor = preferences.edit();
        lastScore = preferences.getLong("lastScore", 0);
        best1 = preferences.getLong("best1", 0);
        best2 = preferences.getLong("best2", 0);
        best3 = preferences.getLong("best3", 0);
        animScale = AnimationUtils.loadAnimation(this , R.anim.anim_scale);
        animAlpha = AnimationUtils.loadAnimation(this , R.anim.anim_alpha);
        explosionWinGif = findViewById(R.id.explosion_win);
        explosionWinGif.setVisibility(View.INVISIBLE);
        bgmusic = MediaPlayer.create(this , R.raw.battleshipsound);
        bgmusic.setLooping(true);
        bgmusic.start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.game_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.music_menu:
            {
             if(isMusicOn) {
             bgmusic.pause();
             isMusicOn = false;
             item.setTitle(getResources().getString(R.string.musicOff));
             }
             else{
                 bgmusic.start();
                 isMusicOn = true;
                 item.setTitle(getResources().getString(R.string.musicOn));
             }
             break;
            }
            case R.id.rules:
            {
                Intent intentGuide = new Intent(GamePage.this, GameGuide.class);
                startActivity(intentGuide);
            }break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(isMusicOn){
            bgmusic.start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(isMusicOn){
            bgmusic.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bgmusic.stop();
        bgmusic.release();
    }
}