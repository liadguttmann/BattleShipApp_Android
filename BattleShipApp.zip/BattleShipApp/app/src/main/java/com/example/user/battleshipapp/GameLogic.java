package com.example.user.battleshipapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.ExifInterface;
import android.os.CountDownTimer;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import java.util.Random;

public final class GameLogic extends Activity {
    private Stage stage;
    private Context context;
    private int numCells1side;
    public TextView textViewGameStage, textViewMessage,textViewTime ;
    private Button buttonAttack, buttonUpgrade, buttonRestart;
    private GridView gridViewBoard1, gridViewBoard2;
    private GameBoard adapterBoard1, adapterBoard2;
    private Player player1, player2;
    AlertDialog.Builder alertDialogBuilder;
    private long timerInMilliSecond = 600000; // 10 min
    public  CountDownTimer countDownTimer = new CountDownTimer(timerInMilliSecond , 1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            timerInMilliSecond = millisUntilFinished;
            updateTimer();
        }

        @Override
        public void onFinish() {
            disableClicking();
            setMessage("Oh No! You Lost Better Luck Next Time, Click RESTART To Play Again");
            AlertDialogLose();
        }
    };
    SharedPreferences preferences;
    private BestScore initialScore;
    SharedPreferences.Editor m_editor;
    Long lastScore;
    Long best1 , best2 , best3;
    Animation animScale , animAlpha;


    public void setFields(Context context, int numCells1side,
                          TextView textViewGameStage, TextView textViewMessage, TextView textViewTime,
                          Button buttonAttack, Button buttonUpgrade, Button buttonRestart,
                          GridView gridViewBoard1, GridView gridViewBoard2,
                          GameBoard adapterBoard1, GameBoard adapterBoard2, SharedPreferences preferences,
                          BestScore initialScore , SharedPreferences.Editor editor,
                          Long best1 , Long best2 , Long best3 , Long lastScore , Animation animScale, Animation animAlpha) {
        this.context = context;
        this.numCells1side = numCells1side;
        this.textViewGameStage = textViewGameStage;
        this.textViewMessage = textViewMessage;
        this.textViewTime = textViewTime;
        this.buttonAttack = buttonAttack;
        this.buttonUpgrade = buttonUpgrade;
        this.buttonRestart = buttonRestart;
        this.gridViewBoard1 = gridViewBoard1;
        this.gridViewBoard2 = gridViewBoard2;
        this.adapterBoard1 = adapterBoard1;
        this.adapterBoard2 = adapterBoard2;
        this.alertDialogBuilder = new AlertDialog.Builder(context);
        this.preferences = preferences;
        this.initialScore = initialScore;
        this.m_editor = editor;
        this.best1 = best1;
        this.best2 = best2;
        this.best3 = best3;
        this.lastScore = lastScore;
        this.animScale = animScale;
        this.animAlpha = animAlpha;
    }

    public void initialize() {
        buttonRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                updateTimerForRestart(timerInMilliSecond);
                initialize();
            }
        });
        disableClicking();
        adapterBoard1.clear();
        adapterBoard2.clear();
        adapterBoard1.addCells(gridViewBoard1, 1, getNumCellsBoardArea());
        adapterBoard2.addCells(gridViewBoard2, 2, getNumCellsBoardArea());

        player1 = new Player(1);
        player2 = new Player(2);

        letP2arrange();
    }


    private void letP2arrange() {
        Model.generateShipPlacement(player2, adapterBoard2, numCells1side);
        enableGameStageArranging();
    }

    private void enableGameStageArranging() {
        putGameStage(Stage.ARRANGING);
        letP1arrange();
    }

    private void letP1arrange() {
        gridViewBoard1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cell cell = (Cell) parent.getAdapter().getItem(position);
                player1.addCell(cell);
                adapterBoard1.notifyDataSetChanged();

                if (player1.canAddCell())
                    setMessage(player1.getShips().get(player1.getNumShipsArranged()).getNumCellsToAdd() +
                            " cell(s) left to add to your ship " +
                            (player1.getNumShipsArranged() + 1));
                else {
                    gridViewBoard1.setOnItemClickListener(null);

                    if (checkArrange()) {
                        enableGameStageBattling();
                    }
                    else
                        AlertDialogArrangement();
                }
            }
        });
    }

    private boolean checkArrange() {
        ShipArrangement shipArr = new ShipArrangement();
        GameBoard adapterBoard = adapterBoard1;
        int c = 0;
        for (int i = 0; i < adapterBoard.getCount(); i++) {
            Cell cell = adapterBoard1.getItem(i);
            if (cell.getStatus() == Cell.Status.OCCUPIED) {
                c = c + 1;
                if (c == 10) {
                    if (((shipArr.checkArrangeLH(adapterBoard)) || (shipArr.checkArrangeLV(adapterBoard)))) {
                        if (((shipArr.checkArrangeMH(adapterBoard)) || (shipArr.checkArrangeMV(adapterBoard)))) {
                            if (((shipArr.checkArrangeSH(adapterBoard)) || (shipArr.checkArrangeSV(adapterBoard)))) {
                                return true;
                            }
                        }
                    }

                }
            }
        }
        return false;
    }

    private void enableGameStageBattling() {
        putGameStage(Stage.BATTLING);
        startTimer();
        enableGameStageAttacking();

        buttonUpgrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(animAlpha);
                player1.upgrade();
                buttonUpgrade.setOnClickListener(null);
                letP2attack();
            }
        });
    }

    private void enableGameStageAttacking() {
        buttonAttack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                putGameStage(Stage.ATTACKING);
                buttonUpgrade.setOnClickListener(null);
                buttonAttack.setOnClickListener(null);
                v.startAnimation(animAlpha);
                letP1attack();
            }
        });
    }

    private void letP1attack() {
        gridViewBoard2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cell cell = (Cell) parent.getAdapter().getItem(position);
                player1.attackCell(cell);
                adapterBoard2.notifyDataSetChanged();

                if (!player2.isAlive()) {
                    disableClicking();
                    countDownTimer.cancel();
                    setMessage("Congratulations You Won! Click RESTART To Play Again");
                    lastScore = timerInMilliSecond;
                    score(lastScore);
                    setInitialScore();
                    updateTimerForRestart(timerInMilliSecond);
                    MainActivity.explosionSound.start();
                    GamePage.explosionWinGif.setVisibility(View.VISIBLE);
                    AlertDialogWin();
                } else if (player1.canAttack()) {
                    Ship ship = player1.getNextShipCanAttack();
                    setMessage(ship.getNumAttacksLeft() + " attack(s) left for your ship " +
                            (player1.getShips().indexOf(ship) + 1));
                } else {
                    gridViewBoard2.setOnItemClickListener(null);
                    player1.resetNumsAttacksMade();
                    letP2attack();
                }
            }
        });
    }

    private void letP2attack() {
        Random random = new Random();
        while (player2.canAttack()) {
            Cell cell;
            do {
                cell = adapterBoard1.getItem(random.nextInt(getNumCellsBoardArea()));
            }
            while (cell.getStatus() == Cell.Status.HIT ||
                    cell.getStatus() == Cell.Status.MISSED);
            player2.attackCell(cell);
            adapterBoard1.notifyDataSetChanged();

            if (!player1.isAlive()) {
                disableClicking();
                countDownTimer.cancel();
                updateTimerForRestart(timerInMilliSecond);
                setMessage("Oh No! You Lost Better Luck Next Time, Click RESTART To Play Again");
                AlertDialogLose();
                break;
            }
        }
        if (player1.isAlive()) {
            player2.resetNumsAttacksMade();
            enableGameStageBattling();
        }
    }

    private void putGameStage(Stage stage) {
        this.stage = stage;
        String msg = "Game stage: " + stage;
        textViewGameStage.setText(msg);
        describeGameStage();
    }

    private void describeGameStage() {
        String msg;
        if (stage == Stage.ARRANGING)
            msg = "tap cell on your board to arrange your " +
                    player1.getNumShips() + " ships";
        else if (stage == Stage.BATTLING)
            msg = "click ATTACK or UPGRADE";
        else
            msg = "tap cell on bot's board to attack its " +
                    player2.getNumShipsAlive() + " alive ship(s)";
        setMessage(msg);
    }

    private void setMessage(String msg) {
        textViewMessage.setText("Message: " + msg);
    }

    private void disableClicking() {
        buttonAttack.setOnClickListener(null);
        buttonUpgrade.setOnClickListener(null);
        gridViewBoard1.setOnItemClickListener(null);
        gridViewBoard2.setOnItemClickListener(null);
    }

    private int getNumCellsBoardArea() {
        return (int) Math.pow(numCells1side, 2);
    }

    private enum Stage {
        ARRANGING, BATTLING, ATTACKING
    }

    public void AlertDialogWin(  ) {

        alertDialogBuilder.setMessage("Congratulations You Won!\n" +"Your Score is: " + lastScore + "\nClick RESTART To Play Again")
                .setCancelable(false).setPositiveButton("RESTART", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                GamePage.explosionWinGif.setVisibility(View.INVISIBLE);
                        initialize();
                finish();
            }
        }).setNegativeButton("Return to Main Menu", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                System.exit(0);
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void AlertDialogLose() {

        alertDialogBuilder.setMessage("Oh No! You Lost Better Luck Next Time\n Click RESTART To Play Again" )
                .setCancelable(false).setPositiveButton("RESTART", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                initialize();
                finish();
            }
        }).setNegativeButton("Return to Main Menu", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                System.exit(0);
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void AlertDialogArrangement() {

        alertDialogBuilder.setMessage("Invalid Arrangement \n Click RESTART To Play Again" )
                .setCancelable(false).setPositiveButton("RESTART", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                initialize();
                finish();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void startTimer(){

        countDownTimer.start();

    }
    public void updateTimer(){
        int minutes = (int) timerInMilliSecond / 60000;
        int seconds = (int) timerInMilliSecond % 60000 / 1000;

        String timeLeftText;

        timeLeftText = "Time Left: " + minutes;
        timeLeftText += ":";

        if(seconds < 10) timeLeftText += "0";
            timeLeftText += seconds;

        textViewTime.setText(timeLeftText);
    }

    public void updateTimerForRestart(Long timerInMilliSecond)
    {
        if (timerInMilliSecond != 600000)
        {
            this.countDownTimer.cancel();
        }
            this.timerInMilliSecond = 600000;
            updateTimer();
    }

    public void score(Long score){
        SharedPreferences.Editor editor = preferences.edit();
        editor.putLong("lastScore" , score);
        editor.apply();
    }
    public void setInitialScore(){

        if(lastScore>best3){
            best3 = lastScore;
            m_editor = preferences.edit();
            m_editor.putLong("best3" , best3);
            m_editor.apply();
        }
        if(lastScore>best2){
            Long temp = best2;
            best2 = lastScore;
            best3 = temp;
            m_editor = preferences.edit();
            m_editor.putLong("best3" , best3);
            m_editor.putLong("best2" , best2);
            m_editor.apply();
        }
        if(lastScore>best1){
            Long temp = best1;
            best1 = lastScore;
            best2 = temp;
            m_editor = preferences.edit();
            m_editor.putLong("best2" , best2);
            m_editor.putLong("best1" , best1);
            m_editor.apply();
        }
    }
}


