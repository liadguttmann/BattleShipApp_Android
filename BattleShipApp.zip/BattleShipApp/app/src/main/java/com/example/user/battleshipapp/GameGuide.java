package com.example.user.battleshipapp;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class GameGuide extends AppCompatActivity {
    Button backToMainMenu, buttonDetails;
    ImageView arrangement , gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_guide);

        backToMainMenu = findViewById(R.id.button_backMainMenu);
        arrangement = findViewById(R.id.iv_arrangement);
        gameView = findViewById(R.id.iv_gameView);
        buttonDetails = findViewById(R.id.button_details);

        arrangement.setScaleType(ImageView.ScaleType.FIT_XY);
        gameView.setScaleType(ImageView.ScaleType.FIT_XY);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (checkSelfPermission(Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this , new String[]{Manifest.permission.INTERNET}, 1);
            }
        }

        backToMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
        buttonDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.ultrabattleship.com/game-rules.php"));
                    startActivity(myIntent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getApplicationContext(), "No application can handle this request."
                            + " Please install a web browser",  Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });
    }
}
